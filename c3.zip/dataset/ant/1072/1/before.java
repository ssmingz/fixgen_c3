class PlaceHold {
  public void test4() {
    expectBuildException("test4", "src invalid");
  }
}
