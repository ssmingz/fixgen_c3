class PlaceHold {
  public void test2() {
    expectBuildException("test2", "attribute src invalid");
  }
}
