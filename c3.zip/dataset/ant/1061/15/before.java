class PlaceHold {
  public Environment() {
    variables = new Vector();
  }
}
