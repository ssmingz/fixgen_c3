class PlaceHold {
  public ReplaceRegExp() {
    super();
    this.file = null;
    this.filesets = new ArrayList();
    this.flags = "";
    this.byline = false;
    this.regex = null;
    this.subs = null;
  }
}
