class PlaceHold {
  protected ArrayList getFilterSets() {
    return m_filterSets;
  }
}
