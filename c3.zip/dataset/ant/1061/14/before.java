class PlaceHold {
  protected Vector getFilterSets() {
    return m_filterSets;
  }
}
