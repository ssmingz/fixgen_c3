class PlaceHold {
  public Vector getGroups(String argument) throws TaskException {
    return getGroups(argument, MATCH_DEFAULT);
  }
}
