class PlaceHold {
  public ArrayList getGroups(String argument) throws TaskException {
    return getGroups(argument, MATCH_DEFAULT);
  }
}
