class PlaceHold {
  protected abstract Vector getOptions();
}
