class PlaceHold {
  protected abstract ArrayList getOptions();
}
