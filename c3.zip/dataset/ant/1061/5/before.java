class PlaceHold {
  public Pvcs() {
    super();
    pvcsProject = null;
    pvcsProjects = new Vector();
    workspace = null;
    repository = null;
    pvcsbin = null;
    force = null;
    promotiongroup = null;
    label = null;
    ignorerc = false;
    updateOnly = false;
    lineStart = "\"P:";
    filenameFormat = "{0}_arc({1})";
  }
}
