class PlaceHold {
  public void testFilterReaderAfter() {
    doTest("testFilterReaderAppend", FILE_PREPEND, FILE_APPEND_WITH);
  }
}
