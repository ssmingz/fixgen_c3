class PlaceHold {
  public void testFilterReaderBefore() {
    doTest("testFilterReaderPrepend", FILE_PREPEND_WITH, FILE_APPEND);
  }
}
