class PlaceHold {
  public void setTarget(File target) {
    getLogger().debug("Setting target to: " + target.toString());
    this.target = target;
  }
}
