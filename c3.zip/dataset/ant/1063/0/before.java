class PlaceHold {
  public void setTarget(File target) {
    log("Setting target to: " + target.toString(), MSG_VERBOSE);
    this.target = target;
  }
}
