class PlaceHold {
  @Test
  public void testAllowMissingFiltersFile() {
    buildRule.executeTarget("testAllowMissingFiltersFile");
  }
}
