class PlaceHold {
  @Test
  public void testXMLWithEntitiesInNonAsciiPath() throws Exception {
    buildRule.executeTarget("testXMLWithEntitiesInNonAsciiPath");
  }
}
