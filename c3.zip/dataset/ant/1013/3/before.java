class PlaceHold {
  public void testXMLWithEntitiesInNonAsciiPath() throws Exception {
    executeTarget("testXMLWithEntitiesInNonAsciiPath");
  }
}
