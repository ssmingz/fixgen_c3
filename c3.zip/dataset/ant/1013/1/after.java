class PlaceHold {
  @Test
  public void testFiltersFileAttribute() {
    buildRule.executeTarget("testFiltersFileAttribute");
  }
}
