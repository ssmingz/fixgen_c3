class PlaceHold {
  @Test
  public void testMoveFileAndFileset() {
    buildRule.executeTarget("testMoveFileAndFileset");
  }
}
