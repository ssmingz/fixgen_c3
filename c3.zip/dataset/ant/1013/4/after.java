class PlaceHold {
  @Test
  public void testMultipleFiltersFiles() {
    buildRule.executeTarget("testMultipleFiltersFiles");
  }
}
