class PlaceHold {
  @Test
  public void testNestedFilesetNoPatterns() {
    buildRule.executeTarget("nestedFilesetNoPatterns");
  }
}
