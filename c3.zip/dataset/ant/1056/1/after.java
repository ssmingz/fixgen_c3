class PlaceHold {
  @Test
  public void testNestedFilesetRef() {
    buildRule.executeTarget("nestedFilesetRef");
  }
}
