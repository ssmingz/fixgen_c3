class PlaceHold {
  @Test
  public void testPathelementPath() {
    buildRule.executeTarget("pathelementPath");
  }
}
