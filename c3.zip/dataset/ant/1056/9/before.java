class PlaceHold {
  public void testNonJavaIncludes() throws Exception {
    executeTarget("nonJavaIncludes");
  }
}
