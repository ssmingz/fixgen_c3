class PlaceHold {
  @Test
  public void testNonJavaIncludes() {
    buildRule.executeTarget("nonJavaIncludes");
  }
}
