class PlaceHold {
  @Test
  public void testNamespaces() {
    buildRule.executeTarget("testNamespaces");
  }
}
