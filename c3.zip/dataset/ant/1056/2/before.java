class PlaceHold {
  public void testNamespaces() throws Exception {
    executeTarget("testNamespaces");
  }
}
