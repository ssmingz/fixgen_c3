class PlaceHold {
  @Test
  public void testUnknownProperty() {
    buildRule.executeTarget("testUnknownProperty");
  }
}
