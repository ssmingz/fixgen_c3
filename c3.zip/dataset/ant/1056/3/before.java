class PlaceHold {
  public void testUnknownProperty() throws Exception {
    executeTarget("testUnknownProperty");
  }
}
