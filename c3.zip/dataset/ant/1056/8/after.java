class PlaceHold {
  @Test
  public void testDirsetPath() {
    buildRule.executeTarget("dirsetPath");
  }
}
