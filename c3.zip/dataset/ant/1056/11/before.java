class PlaceHold {
  public void testNestedSource() throws Exception {
    executeTarget("nestedSource");
  }
}
