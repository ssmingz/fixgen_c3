class PlaceHold {
  @Test
  public void testNestedSource() {
    buildRule.executeTarget("nestedSource");
  }
}
