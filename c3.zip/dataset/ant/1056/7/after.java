class PlaceHold {
  @Test
  public void testDoublyNestedFilesetNoPatterns() {
    buildRule.executeTarget("doublyNestedFilesetNoPatterns");
  }
}
