class PlaceHold {
  @Test
  public void testNestedDirsetPath() {
    buildRule.executeTarget("nestedDirsetPath");
  }
}
