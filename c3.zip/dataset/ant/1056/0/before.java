class PlaceHold {
  public void testNestedDirsetPath() throws Exception {
    executeTarget("nestedDirsetPath");
  }
}
