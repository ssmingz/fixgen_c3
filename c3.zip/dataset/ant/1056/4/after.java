class PlaceHold {
  @Test
  public void testNestedFilesetRefInPath() {
    buildRule.executeTarget("nestedFilesetRefInPath");
  }
}
