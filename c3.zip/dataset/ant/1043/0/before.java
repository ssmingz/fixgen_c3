class PlaceHold {
  public void setUp() {
    configureProject("src/etc/testcases/core/immutable.xml");
  }
}
