class PlaceHold {
  @Before
  public void setUp() {
    buildRule.configureProject("src/etc/testcases/core/immutable.xml");
  }
}
