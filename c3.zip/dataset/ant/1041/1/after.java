class PlaceHold {
  public void setUnicodeinput(boolean unicodeInput) {
    optionalAttrs.put(UNICODE_INPUT, unicodeInput ? Boolean.TRUE : Boolean.FALSE);
  }
}
