class PlaceHold {
  public void setUnicodeinput(boolean unicodeInput) {
    optionalAttrs.put(UNICODE_INPUT, new Boolean(unicodeInput));
  }
}
