class PlaceHold {
  public void setNodescopehook(boolean nodeScopeHook) {
    optionalAttrs.put(NODE_SCOPE_HOOK, nodeScopeHook ? Boolean.TRUE : Boolean.FALSE);
  }
}
