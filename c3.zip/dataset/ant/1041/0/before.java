class PlaceHold {
  public void setNodescopehook(boolean nodeScopeHook) {
    optionalAttrs.put(NODE_SCOPE_HOOK, new Boolean(nodeScopeHook));
  }
}
