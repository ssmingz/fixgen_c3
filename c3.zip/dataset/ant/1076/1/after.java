class PlaceHold {
  public void tearDown() {
    executeTarget("cleanup");
  }
}
