class PlaceHold {
  public void tearDown() {
    project.executeTarget("cleanup");
  }
}
