class PlaceHold {
  private String getIncludeDefaultReferencesParameter() {
    return "/nostdlib" + (m_includeDefaultReferences ? "-" : "+");
  }
}
