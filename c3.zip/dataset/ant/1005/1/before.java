class PlaceHold {
  public void setSkipEmptyFilesets(boolean skip) {
    throw new BuildException(
        taskType + " doesn\'t support the skipemptyfileset attribute", location);
  }
}
