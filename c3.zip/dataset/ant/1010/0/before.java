class PlaceHold {
  public void setUp() {
    configureProject("src/etc/testcases/taskdefs/conditions/isreference.xml");
  }
}
