class PlaceHold {
  @Before
  public void setUp() {
    buildRule.configureProject("src/etc/testcases/types/poly.xml");
  }
}
