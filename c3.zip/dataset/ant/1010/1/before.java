class PlaceHold {
  public void setUp() {
    configureProject("src/etc/testcases/types/poly.xml");
  }
}
