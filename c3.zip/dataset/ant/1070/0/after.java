class PlaceHold {
  protected String getVerbose() {
    return verbose ? FLAG_VERBOSE : "";
  }
}
