class PlaceHold {
  protected String getNoCache() {
    return noCache ? FLAG_NO_CACHE : "";
  }
}
