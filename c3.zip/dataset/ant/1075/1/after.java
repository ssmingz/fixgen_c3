class PlaceHold {
  protected void setExtra() {
    super.setExtra(ExtraFieldUtils.mergeLocalFileDataData(getExtraFields(true)));
  }
}
