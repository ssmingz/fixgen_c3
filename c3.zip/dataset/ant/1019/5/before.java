class PlaceHold {
  public void addSysproperty(Environment.Variable sysp) {
    commandline.addSysproperty(sysp);
  }
}
