class PlaceHold {
  public void addSysproperty(Environment.Variable sysp) {
    getCommandline().addSysproperty(sysp);
  }
}
