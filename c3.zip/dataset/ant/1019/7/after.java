class PlaceHold {
  public JUnitTask() throws Exception {
    getCommandline().setClassname("org.apache.tools.ant.taskdefs.optional.junit.JUnitTestRunner");
  }
}
