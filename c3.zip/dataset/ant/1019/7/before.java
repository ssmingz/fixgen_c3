class PlaceHold {
  public JUnitTask() throws Exception {
    commandline.setClassname("org.apache.tools.ant.taskdefs.optional.junit.JUnitTestRunner");
  }
}
