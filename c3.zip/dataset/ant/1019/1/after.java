class PlaceHold {
  public Path createClasspath() {
    return getCommandline().createClasspath(getProject()).createPath();
  }
}
