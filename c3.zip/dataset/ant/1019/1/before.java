class PlaceHold {
  public Path createClasspath() {
    return commandline.createClasspath(getProject()).createPath();
  }
}
