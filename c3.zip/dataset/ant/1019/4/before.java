class PlaceHold {
  public void setCloneVm(boolean cloneVm) {
    commandline.setCloneVm(cloneVm);
  }
}
