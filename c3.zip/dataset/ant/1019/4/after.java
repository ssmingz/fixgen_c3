class PlaceHold {
  public void setCloneVm(boolean cloneVm) {
    getCommandline().setCloneVm(cloneVm);
  }
}
