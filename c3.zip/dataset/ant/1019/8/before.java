class PlaceHold {
  public void setMaxmemory(String max) {
    commandline.setMaxmemory(max);
  }
}
