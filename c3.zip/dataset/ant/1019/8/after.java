class PlaceHold {
  public void setMaxmemory(String max) {
    getCommandline().setMaxmemory(max);
  }
}
