class PlaceHold {
  public Path createBootclasspath() {
    return commandline.createBootclasspath(getProject()).createPath();
  }
}
