class PlaceHold {
  public void setJvm(String value) {
    commandline.setVm(value);
  }
}
