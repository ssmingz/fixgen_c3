class PlaceHold {
  public void addSyspropertyset(PropertySet sysp) {
    commandline.addSyspropertyset(sysp);
  }
}
