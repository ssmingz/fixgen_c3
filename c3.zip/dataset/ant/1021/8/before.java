class PlaceHold {
  protected void loadProperties(ClassLoader al, URL url) {
    InputStream is = null;
    try {
      is = url.openStream();
      if (is == null) {
        log("Could not load definitions from " + url, MSG_WARN);
        return;
      }
      Properties props = new Properties();
      props.load(is);
      Enumeration keys = props.keys();
      while (keys.hasMoreElements()) {
        name = ((String) (keys.nextElement()));
        classname = props.getProperty(name);
        addDefinition(al, name, classname);
      }
    } catch (IOException ex) {
      throw new BuildException(ex, getLocation());
    } finally {
      if (is != null) {
        try {
          is.close();
        } catch (IOException e) {
        }
      }
    }
  }
}
