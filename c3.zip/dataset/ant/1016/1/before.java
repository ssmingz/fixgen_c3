class PlaceHold {
  public synchronized void setOutputFilterChains(Vector outputFilterChains) {
    this.outputFilterChains = outputFilterChains;
  }
}
