class PlaceHold {
  public synchronized void setAppendProperties(boolean appendProperties) {
    this.appendProperties = appendProperties;
  }
}
