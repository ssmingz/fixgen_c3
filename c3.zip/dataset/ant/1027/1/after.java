class PlaceHold {
  @Test
  public void testAtLeast() {
    buildRule.executeTarget("testatleast");
  }
}
