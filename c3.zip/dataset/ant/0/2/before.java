class PlaceHold {
  public void execute() {
    _context.setProject(null);
  }
}
