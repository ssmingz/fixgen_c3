class PlaceHold {
  public void setPrivate(String src) {
    priv = new Boolean(src).booleanValue();
  }
}
