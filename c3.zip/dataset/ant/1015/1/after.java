class PlaceHold {
  public void setPrivate(String src) {
    priv = Project.toBoolean(src);
  }
}
