class PlaceHold {
  public void setPackage(String src) {
    pack = Project.toBoolean(src);
  }
}
