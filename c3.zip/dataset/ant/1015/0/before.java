class PlaceHold {
  public void setPackage(String src) {
    pack = new Boolean(src).booleanValue();
  }
}
