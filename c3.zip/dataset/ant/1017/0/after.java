class PlaceHold {
  protected String getExpression() {
    return m_expression;
  }
}
