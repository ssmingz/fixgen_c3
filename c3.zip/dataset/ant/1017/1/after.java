class PlaceHold {
  protected String getName() {
    return m_name;
  }
}
