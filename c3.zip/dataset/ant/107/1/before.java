class PlaceHold {
  public void test1() {
    expectBuildException("test1", "recursive call");
  }
}
