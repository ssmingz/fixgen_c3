class PlaceHold {
  public void setExecutable(String value) {
    this.executable = value;
  }
}
