class PlaceHold {
  public void setExecutable(String value) {
    this.executable = value;
    cmdl.setExecutable(value);
  }
}
