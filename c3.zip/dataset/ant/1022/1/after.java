class PlaceHold {
  public String getLoaderId() {
    return cpDelegate.getClassLoadId();
  }
}
