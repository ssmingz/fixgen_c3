class PlaceHold {
  public String getClasspathId() {
    return cpDelegate.getClassLoadId();
  }
}
