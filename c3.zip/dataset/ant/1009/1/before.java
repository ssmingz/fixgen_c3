class PlaceHold {
  public static boolean addDefaultExclude(String s) {
    return defaultExcludes.add(s);
  }
}
