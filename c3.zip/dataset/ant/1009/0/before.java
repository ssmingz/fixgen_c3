class PlaceHold {
  public static boolean removeDefaultExclude(String s) {
    return defaultExcludes.remove(s);
  }
}
