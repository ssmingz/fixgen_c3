class PlaceHold {
  @Test
  public void testSetMultiple() {
    buildRule.executeTarget("testSetMultiple");
  }
}
