class PlaceHold {
  public void testDefaultDest() throws Exception {
    executeTarget("testDefaultDest");
  }
}
