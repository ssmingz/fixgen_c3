class PlaceHold {
  @Test
  public void testDefaultDest() throws Exception {
    buildRule.executeTarget("testDefaultDest");
  }
}
