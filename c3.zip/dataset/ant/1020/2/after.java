class PlaceHold {
  @Test
  public void testAntClasspath() throws Exception {
    buildRule.executeTarget("testAntClasspath");
  }
}
