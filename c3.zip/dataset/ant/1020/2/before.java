class PlaceHold {
  public void testAntClasspath() throws Exception {
    executeTarget("testAntClasspath");
  }
}
