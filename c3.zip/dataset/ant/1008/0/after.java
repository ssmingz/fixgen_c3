class PlaceHold {
  public void setEmbeddorProperty(final String name, final Object value) {
    m_embeddorParameters.setParameter(name, value.toString());
  }
}
