class PlaceHold {
  public void setBuilderProperty(final String name, final Object value) {
    m_builderProps.setParameter(name, ((String) (value)));
  }
}
