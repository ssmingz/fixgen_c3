class PlaceHold {
  public void test4() {
    expectBuildException("test4", "target attribute must not be empty");
  }
}
